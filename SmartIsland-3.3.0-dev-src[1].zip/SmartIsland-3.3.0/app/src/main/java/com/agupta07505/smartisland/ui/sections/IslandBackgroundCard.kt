/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui.sections

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agupta07505.smartisland.data.SmartIslandSettings
import com.agupta07505.smartisland.data.SmartIslandSettingsRepository
import com.agupta07505.smartisland.ui.components.SettingsCard
import com.agupta07505.smartisland.ui.components.SettingsDivider
import com.agupta07505.smartisland.ui.components.SettingsSliderRow
import com.agupta07505.smartisland.ui.components.SettingsSwitchRow
import com.agupta07505.smartisland.util.IslandBackgroundStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BACKGROUND_PRESETS = listOf(
    0xFF000000L to "Black",
    0xFF111827L to "Charcoal",
    0xFF1E1B4B to "Indigo",
    0xFF0F3D2E to "Forest",
    0xFF3B0764L to "Plum",
    0xFF7F1D1D to "Maroon"
)

/**
 * Lets the user restyle the island shell itself: a solid colour, a photo of
 * their own, or the album art of whatever is playing.
 */
@Composable
fun IslandBackgroundCard(
    settings: SmartIslandSettings,
    repository: SmartIslandSettingsRepository,
    onCustomColorRequested: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        importing = true
        scope.launch {
            // The picked uri is only granted to this process for this task, so the
            // image is copied into private storage before it is remembered.
            val storedPath = withContext(Dispatchers.IO) {
                IslandBackgroundStore.importImage(context, uri)
            }
            if (storedPath != null) {
                repository.setIslandBackgroundImagePath(storedPath)
            }
            importing = false
        }
    }

    // Preview of whatever is currently configured, so the settings screen shows
    // the same thing the island will render.
    var preview by remember(settings.islandBackgroundImagePath) {
        mutableStateOf<Bitmap?>(null)
    }
    LaunchedEffect(settings.islandBackgroundImagePath) {
        preview = withContext(Dispatchers.IO) {
            IslandBackgroundStore.load(settings.islandBackgroundImagePath)
        }
    }

    SettingsCard {
        Column(Modifier.padding(20.dp)) {
            Text(
                text = "Island background",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Pick the colour behind the island, or replace it with an image of your own.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
            )

            IslandPreview(
                backgroundColor = Color(settings.islandBackgroundColor),
                image = preview,
                imageAlpha = settings.islandBackgroundImageAlpha
            )

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BACKGROUND_PRESETS.forEach { (colorValue, name) ->
                    ColorSwatch(
                        color = Color(colorValue),
                        contentDescription = name,
                        isSelected = settings.islandBackgroundColor == colorValue,
                        onClick = {
                            scope.launch { repository.setIslandBackgroundColor(colorValue) }
                        }
                    )
                }
                CustomColorSwatch(
                    isSelected = BACKGROUND_PRESETS.none {
                        it.first == settings.islandBackgroundColor
                    },
                    onClick = onCustomColorRequested
                )
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        pickImageLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    enabled = !importing,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = when {
                            importing -> "Importing…"
                            settings.islandBackgroundImagePath.isNotBlank() -> "Change image"
                            else -> "Choose image"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (settings.islandBackgroundImagePath.isNotBlank()) {
                    TextButton(
                        onClick = {
                            scope.launch {
                                repository.setIslandBackgroundImagePath("")
                                withContext(Dispatchers.IO) { IslandBackgroundStore.clear(context) }
                            }
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Remove", fontSize = 13.sp)
                    }
                }
            }
        }

        if (settings.islandBackgroundImagePath.isNotBlank()) {
            SettingsDivider()
            SettingsSliderRow(
                title = "Image opacity",
                description = "How strongly the image shows through over the background colour.",
                value = settings.islandBackgroundImageAlpha,
                valueLabel = "${(settings.islandBackgroundImageAlpha * 100).toInt()}%",
                valueRange = SmartIslandSettings.MIN_BACKGROUND_IMAGE_ALPHA..
                    SmartIslandSettings.MAX_BACKGROUND_IMAGE_ALPHA,
                onValueChange = { value ->
                    scope.launch { repository.setIslandBackgroundImageAlpha(value) }
                }
            )
        }

        SettingsDivider()

        SettingsSwitchRow(
            title = "Use album art as background",
            description = "While music is playing, dim the current album art behind the island.",
            checked = settings.useArtworkBackground,
            onCheckedChange = { checked ->
                scope.launch { repository.setUseArtworkBackground(checked) }
            }
        )
    }
}

@Composable
private fun IslandPreview(
    backgroundColor: Color,
    image: Bitmap?,
    imageAlpha: Float
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(150.dp)
                .height(38.dp)
                .clip(RoundedCornerShape(19.dp))
                .background(backgroundColor)
        ) {
            if (image != null) {
                Image(
                    bitmap = image.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = imageAlpha,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Text(
                text = "Preview",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun ColorSwatch(
    color: Color,
    contentDescription: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderModifier = if (isSelected) {
        Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
    } else {
        Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
    }
    Box(
        modifier = Modifier
            .size(34.dp)
            .then(borderModifier)
            .padding(2.dp)
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = contentDescription,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun CustomColorSwatch(isSelected: Boolean, onClick: () -> Unit) {
    val rainbow = remember {
        Brush.linearGradient(
            listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta)
        )
    }
    val borderModifier = if (isSelected) {
        Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
    } else {
        Modifier
    }
    Box(
        modifier = Modifier
            .size(34.dp)
            .then(borderModifier)
            .padding(2.dp)
            .clip(CircleShape)
            .background(rainbow)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Custom colour",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
