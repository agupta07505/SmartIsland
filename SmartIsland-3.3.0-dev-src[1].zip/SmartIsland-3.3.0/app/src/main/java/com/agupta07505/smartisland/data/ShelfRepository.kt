/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.data

import com.agupta07505.smartisland.model.ShelfItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Holds the handful of recent screenshots / clipboard captures that the island
 * shelf offers to share.
 *
 * Intentionally in-memory only: captures can contain anything the user happened
 * to copy, so they are never persisted and they disappear when the service dies.
 */
class ShelfRepository {
    private val _items = MutableStateFlow<List<ShelfItem>>(emptyList())
    val items: StateFlow<List<ShelfItem>> = _items.asStateFlow()

    fun add(item: ShelfItem) {
        _items.update { current ->
            // Re-capturing the same uri/text should refresh it rather than duplicate.
            val deduplicated = current.filterNot { existing ->
                (item.contentUri != null && existing.contentUri == item.contentUri) ||
                    (item.text != null && existing.text == item.text)
            }
            (listOf(item) + deduplicated).take(MAX_ITEMS)
        }
    }

    fun remove(id: String) {
        _items.update { current -> current.filterNot { it.id == id } }
    }

    fun clear() {
        _items.value = emptyList()
    }

    val hasItems: Boolean
        get() = _items.value.isNotEmpty()

    private companion object {
        const val MAX_ITEMS = 8
    }
}
