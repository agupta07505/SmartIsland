/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/**
 * Owns the image a user picks as their island background.
 *
 * The picked image is *copied* into the app's private files directory rather
 * than referenced by its original content:// uri. That matters because the
 * island is rendered by the accessibility service, which may outlive the grant
 * on the picker's uri — a copy is the only thing guaranteed to still be
 * readable a week later after a reboot.
 */
object IslandBackgroundStore {

    private const val TAG = "IslandBackgroundStore"
    private const val FILE_NAME = "island_background.png"

    /** Longest edge of the stored copy. The island is tiny; anything larger is wasted memory. */
    private const val MAX_DIMENSION = 720

    fun backgroundFile(context: Context): File =
        File(context.applicationContext.filesDir, FILE_NAME)

    /**
     * Copies [source] into private storage, downscaling it first.
     *
     * @return the absolute path of the stored copy, or null if the image could
     *   not be read (permission revoked, unsupported format, out of space).
     */
    fun importImage(context: Context, source: Uri): String? {
        val appContext = context.applicationContext
        val bitmap = decodeScaled(appContext, source) ?: return null
        val target = backgroundFile(appContext)

        val written = runCatchingLogged(TAG, "Failed to write island background") {
            target.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            true
        } ?: false

        if (!bitmap.isRecycled) bitmap.recycle()
        return if (written && target.exists()) target.absolutePath else null
    }

    /** Deletes the stored background, if any. */
    fun clear(context: Context) {
        runCatchingLogged(TAG, "Failed to delete island background") {
            val file = backgroundFile(context.applicationContext)
            if (file.exists()) file.delete()
        }
    }

    /**
     * Loads the stored background. Returns null when [path] is blank or the file
     * has gone missing, which callers treat as "fall back to the solid color".
     */
    fun load(path: String): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists()) return null
        return runCatchingLogged(TAG, "Failed to decode island background") {
            BitmapFactory.decodeFile(file.absolutePath)
        }
    }

    private fun decodeScaled(context: Context, source: Uri): Bitmap? {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatchingLogged(TAG, "Failed to read image bounds") {
            resolver.openInputStream(source)?.use { input ->
                BitmapFactory.decodeStream(input, null, bounds)
            }
        } ?: return null

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val options = BitmapFactory.Options().apply {
            inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        return runCatchingLogged(TAG, "Failed to decode picked image") {
            resolver.openInputStream(source)?.use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }
        }
    }

    private fun calculateSampleSize(width: Int, height: Int): Int {
        var sampleSize = 1
        var longestEdge = maxOf(width, height)
        while (longestEdge / 2 >= MAX_DIMENSION) {
            longestEdge /= 2
            sampleSize *= 2
        }
        return sampleSize
    }
}
