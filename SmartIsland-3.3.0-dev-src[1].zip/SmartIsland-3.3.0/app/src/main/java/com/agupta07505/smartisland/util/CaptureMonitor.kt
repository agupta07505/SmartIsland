/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.util

import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.core.content.ContextCompat
import com.agupta07505.smartisland.model.ShelfItem
import com.agupta07505.smartisland.model.ShelfItemType
import java.util.UUID

/**
 * Watches for two things worth surfacing on the island: a screenshot the user
 * just took, and text they just copied.
 *
 * Screenshots are detected through a MediaStore observer — reliable, and the
 * only approach that does not need a screen-capture projection.
 *
 * Clipboard capture is best-effort by design. Since Android 10, an app that is
 * not the foreground app or the active IME gets null back from
 * [ClipboardManager.getPrimaryClip], and there is no permission a normal app can
 * hold to change that. The listener is still registered because it works on
 * Android 9 and on ROMs that relax the restriction; when the read comes back
 * empty we simply skip the capture rather than showing an empty shelf card.
 */
class CaptureMonitor(
    context: Context,
    private val onCapture: (ShelfItem) -> Unit
) {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    private var screenshotObserver: ContentObserver? = null
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private var lastHandledImageId = -1L
    private var lastClipboardText: String? = null
    private var startedAtMillis = 0L

    fun start(watchScreenshots: Boolean, watchClipboard: Boolean) {
        startedAtMillis = System.currentTimeMillis()
        if (watchScreenshots) startScreenshotObserver()
        if (watchClipboard) startClipboardListener()
    }

    fun stop() {
        screenshotObserver?.let { observer ->
            runCatchingLogged(TAG, "Failed to unregister screenshot observer") {
                appContext.contentResolver.unregisterContentObserver(observer)
            }
        }
        screenshotObserver = null

        clipboardListener?.let { listener ->
            runCatchingLogged(TAG, "Failed to remove clipboard listener") {
                clipboardManager()?.removePrimaryClipChangedListener(listener)
            }
        }
        clipboardListener = null
    }

    // ── Screenshots ──────────────────────────────────────────────────────────

    private fun startScreenshotObserver() {
        if (screenshotObserver != null) return
        if (!hasImageReadPermission(appContext)) {
            android.util.Log.i(TAG, "Screenshot watching skipped: media permission not granted")
            return
        }

        val observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                runCatchingLogged(TAG, "Screenshot observer failed") {
                    handleLatestImage()
                }
            }
        }

        runCatchingLogged(TAG, "Failed to register screenshot observer") {
            appContext.contentResolver.registerContentObserver(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                true,
                observer
            )
            screenshotObserver = observer
        }
    }

    private fun handleLatestImage() {
        val projection = buildList {
            add(MediaStore.Images.Media._ID)
            add(MediaStore.Images.Media.DISPLAY_NAME)
            add(MediaStore.Images.Media.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Images.Media.RELATIVE_PATH)
            } else {
                @Suppress("DEPRECATION")
                add(MediaStore.Images.Media.DATA)
            }
        }.toTypedArray()

        val cursor = runCatchingLogged(TAG, "Failed to query MediaStore") {
            appContext.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                // No SQL LIMIT here: Android 11+ rejects LIMIT inside sortOrder for
                // MediaStore queries. We only read the first row anyway.
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )
        } ?: return

        cursor.use {
            if (!it.moveToFirst()) return

            val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
            if (id == lastHandledImageId) return

            val displayName = it
                .getStringOrNull(MediaStore.Images.Media.DISPLAY_NAME)
                .orEmpty()
            val pathColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.RELATIVE_PATH
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.DATA
            }
            val path = it.getStringOrNull(pathColumn).orEmpty()
            val dateAddedSeconds =
                it.getLong(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED))

            if (!looksLikeScreenshot(displayName, path)) return

            // Ignore anything that existed before we started watching, and anything
            // that is not brand new — otherwise a media rescan replays old images.
            val ageMillis = System.currentTimeMillis() - (dateAddedSeconds * 1000L)
            if (ageMillis > FRESH_CAPTURE_WINDOW_MS) return
            if (dateAddedSeconds * 1000L < startedAtMillis - FRESH_CAPTURE_WINDOW_MS) return

            lastHandledImageId = id

            val contentUri = ContentUris.withAppendedId(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                id
            )

            onCapture(
                ShelfItem(
                    id = "screenshot_$id",
                    type = ShelfItemType.Screenshot,
                    contentUri = contentUri.toString(),
                    thumbnail = loadThumbnail(contentUri)
                )
            )
        }
    }

    private fun looksLikeScreenshot(displayName: String, path: String): Boolean {
        val haystack = (displayName + " " + path).lowercase()
        return SCREENSHOT_HINTS.any { haystack.contains(it) }
    }

    private fun loadThumbnail(uri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatchingLogged(TAG, "loadThumbnail failed") {
                return appContext.contentResolver.loadThumbnail(
                    uri,
                    Size(THUMBNAIL_SIZE, THUMBNAIL_SIZE),
                    null
                )
            }
        }
        return runCatchingLogged(TAG, "Legacy thumbnail decode failed") {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                val options = BitmapFactory.Options().apply { inSampleSize = 8 }
                BitmapFactory.decodeStream(input, null, options)
            }
        }
    }

    // ── Clipboard ────────────────────────────────────────────────────────────

    private fun startClipboardListener() {
        if (clipboardListener != null) return
        val manager = clipboardManager() ?: return

        val listener = ClipboardManager.OnPrimaryClipChangedListener {
            runCatchingLogged(TAG, "Clipboard listener failed") {
                handleClipboardChange(manager)
            }
        }

        runCatchingLogged(TAG, "Failed to add clipboard listener") {
            manager.addPrimaryClipChangedListener(listener)
            clipboardListener = listener
        }
    }

    private fun handleClipboardChange(manager: ClipboardManager) {
        val clip = manager.primaryClip
        if (clip == null || clip.itemCount == 0) {
            // Expected on Android 10+ when we are not the foreground app.
            android.util.Log.d(TAG, "Clipboard change received but content is not readable")
            return
        }

        val text = clip.getItemAt(0)?.coerceToText(appContext)?.toString()?.trim()
        if (text.isNullOrEmpty()) return
        if (text == lastClipboardText) return
        lastClipboardText = text

        onCapture(
            ShelfItem(
                id = "clip_${UUID.randomUUID()}",
                type = ShelfItemType.Text,
                text = text.take(MAX_CLIPBOARD_CHARS)
            )
        )
    }

    private fun clipboardManager(): ClipboardManager? =
        runCatchingLogged(TAG, "ClipboardManager unavailable") {
            appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        }

    private fun android.database.Cursor.getStringOrNull(column: String): String? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getString(index) else null
    }

    companion object {
        private const val TAG = "CaptureMonitor"
        private const val THUMBNAIL_SIZE = 256
        private const val MAX_CLIPBOARD_CHARS = 4000
        private const val FRESH_CAPTURE_WINDOW_MS = 15_000L

        private val SCREENSHOT_HINTS = listOf("screenshot", "screen_shot", "screencapture", "screen-")

        /**
         * Reading images out of MediaStore needs a runtime permission, and the
         * permission changed name in Android 13.
         */
        fun requiredImagePermission(): String =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                android.Manifest.permission.READ_MEDIA_IMAGES
            } else {
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            }

        fun hasImageReadPermission(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                requiredImagePermission()
            ) == PackageManager.PERMISSION_GRANTED
    }
}
