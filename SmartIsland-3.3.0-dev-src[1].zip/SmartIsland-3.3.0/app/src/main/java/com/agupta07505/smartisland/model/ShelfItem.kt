/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.model

import android.graphics.Bitmap

/**
 * One entry on the island shelf: either a screenshot that was just taken, or a
 * chunk of text that was just copied to the clipboard.
 *
 * Shelf entries are deliberately in-memory only. Nothing is written to disk and
 * nothing leaves the device — the shelf is a short-lived staging area that the
 * user either shares, copies, or discards.
 */
data class ShelfItem(
    val id: String,
    val type: ShelfItemType,
    /** MediaStore content:// uri for [ShelfItemType.Screenshot]. */
    val contentUri: String? = null,
    /** Clipboard payload for [ShelfItemType.Text]. */
    val text: String? = null,
    /** Small preview bitmap for screenshots, decoded at a bounded sample size. */
    val thumbnail: Bitmap? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val label: String
        get() = when (type) {
            ShelfItemType.Screenshot -> "Screenshot"
            ShelfItemType.Text -> text?.take(TEXT_PREVIEW_LENGTH).orEmpty()
        }

    private companion object {
        const val TEXT_PREVIEW_LENGTH = 120
    }
}

enum class ShelfItemType {
    Screenshot,
    Text
}
