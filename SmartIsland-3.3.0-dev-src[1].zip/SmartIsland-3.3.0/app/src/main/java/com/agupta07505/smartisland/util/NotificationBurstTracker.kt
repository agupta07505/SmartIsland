/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.util

import android.os.SystemClock

/**
 * Tracks how chatty each app has been recently so the island can stop popping
 * open when one source floods it.
 *
 * With the default threshold of 3, the first two notifications from an app
 * expand the island as usual; the third and every one after it inside the same
 * rolling window are delivered silently — they still land in the island's
 * notification list, they just do not animate it open.
 *
 * The window resets on its own, so a burst of group-chat messages goes quiet but
 * the next message an hour later is treated as fresh again.
 */
class NotificationBurstTracker(
    private val windowMillis: Long = DEFAULT_WINDOW_MILLIS,
    private val clock: () -> Long = { SystemClock.elapsedRealtime() }
) {
    private val timestampsByPackage = HashMap<String, ArrayDeque<Long>>()

    /**
     * Records one notification from [packageName] and reports whether it should
     * be delivered silently.
     *
     * @param threshold how many notifications inside the window are allowed to
     *   expand the island before the rest are silenced.
     */
    @Synchronized
    fun recordAndCheckSilenced(packageName: String, threshold: Int): Boolean {
        if (threshold <= 0) return false
        val now = clock()
        val cutoff = now - windowMillis

        val queue = timestampsByPackage.getOrPut(packageName) { ArrayDeque() }
        while (queue.isNotEmpty() && queue.first() < cutoff) {
            queue.removeFirst()
        }
        queue.addLast(now)

        pruneIfNeeded(cutoff)

        return queue.size >= threshold
    }

    /** How many notifications from [packageName] are still inside the window. */
    @Synchronized
    fun countFor(packageName: String): Int {
        val cutoff = clock() - windowMillis
        val queue = timestampsByPackage[packageName] ?: return 0
        while (queue.isNotEmpty() && queue.first() < cutoff) {
            queue.removeFirst()
        }
        return queue.size
    }

    /** Called when the user clears an app's notifications, so it starts over. */
    @Synchronized
    fun reset(packageName: String) {
        timestampsByPackage.remove(packageName)
    }

    @Synchronized
    fun clear() {
        timestampsByPackage.clear()
    }

    private fun pruneIfNeeded(cutoff: Long) {
        if (timestampsByPackage.size <= MAX_TRACKED_PACKAGES) return
        val iterator = timestampsByPackage.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            while (entry.value.isNotEmpty() && entry.value.first() < cutoff) {
                entry.value.removeFirst()
            }
            if (entry.value.isEmpty()) iterator.remove()
        }
    }

    companion object {
        const val DEFAULT_WINDOW_MILLIS = 60_000L
        private const val MAX_TRACKED_PACKAGES = 64
    }
}
