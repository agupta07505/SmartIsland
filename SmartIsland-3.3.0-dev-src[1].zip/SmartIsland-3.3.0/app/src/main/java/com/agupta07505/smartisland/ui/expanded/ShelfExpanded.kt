/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui.expanded

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agupta07505.smartisland.model.ShelfItem
import com.agupta07505.smartisland.model.ShelfItemType
import com.agupta07505.smartisland.ui.bounceClick

/**
 * The capture shelf: whatever the user just screenshotted or copied, staged with
 * one tap between it and the share sheet.
 */
@Composable
fun ShelfExpanded(
    items: List<ShelfItem>,
    bottomPadding: Dp,
    onShare: (ShelfItem) -> Unit,
    onCopy: (ShelfItem) -> Unit,
    onRemove: (ShelfItem) -> Unit,
    onClearAll: () -> Unit
) {
    if (items.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(start = 18.dp, top = 20.dp, end = 18.dp, bottom = bottomPadding)
        ) {
            Text("Shelf is empty", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Screenshots and copied text will appear here.",
                color = Color(0xFFB7C0CA),
                fontSize = 12.sp
            )
        }
        return
    }

    var selectedId by remember(items.firstOrNull()?.id) {
        mutableStateOf(items.first().id)
    }
    val selected = items.firstOrNull { it.id == selectedId } ?: items.first()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(start = 18.dp, top = 16.dp, end = 18.dp, bottom = bottomPadding)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SelectedPreview(selected)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = if (selected.type == ShelfItemType.Screenshot) "Screenshot" else "Copied text",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Text(
                    text = selected.label.ifBlank { "Ready to share" },
                    color = Color(0xFFD5DAE0),
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            ShelfActionButton(
                icon = Icons.Rounded.Close,
                description = "Dismiss capture",
                onClick = { onRemove(selected) }
            )
        }

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShelfPrimaryButton(
                icon = Icons.Rounded.IosShare,
                label = "Share",
                modifier = Modifier.weight(1f),
                onClick = { onShare(selected) }
            )
            ShelfPrimaryButton(
                icon = Icons.Rounded.ContentCopy,
                label = "Copy",
                modifier = Modifier.weight(1f),
                onClick = { onCopy(selected) }
            )
            ShelfActionButton(
                icon = Icons.Rounded.DeleteSweep,
                description = "Clear shelf",
                onClick = onClearAll
            )
        }

        if (items.size > 1) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items.forEach { item ->
                    ShelfThumbnail(
                        item = item,
                        isSelected = item.id == selected.id,
                        onClick = { selectedId = item.id }
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectedPreview(item: ShelfItem) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1F2937)),
        contentAlignment = Alignment.Center
    ) {
        val thumbnail = item.thumbnail
        if (thumbnail != null) {
            Image(
                bitmap = thumbnail.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(46.dp)
            )
        } else {
            Icon(
                imageVector = if (item.type == ShelfItemType.Screenshot) {
                    Icons.Rounded.PhotoLibrary
                } else {
                    Icons.Rounded.ContentCopy
                },
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ShelfThumbnail(item: ShelfItem, isSelected: Boolean, onClick: () -> Unit) {
    val borderColor = if (isSelected) Color(0xFF67E8F9) else Color.Transparent
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1F2937))
            .border(1.5.dp, borderColor, RoundedCornerShape(8.dp))
            .bounceClick(onClick),
        contentAlignment = Alignment.Center
    ) {
        val thumbnail = item.thumbnail
        if (thumbnail != null) {
            Image(
                bitmap = thumbnail.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(34.dp)
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.ContentCopy,
                contentDescription = null,
                tint = Color(0xFFB7C0CA),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun ShelfPrimaryButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(Color(0xFF2A3441))
            .bounceClick(onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ShelfActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(Color(0xFF2A3441))
            .bounceClick(onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(16.dp))
    }
}
