/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.agupta07505.smartisland.data.SmartIslandSettings
import com.agupta07505.smartisland.model.IslandMode
import com.agupta07505.smartisland.util.IslandBackgroundStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Paints whatever the user chose to sit behind the island contents.
 *
 * Layers, bottom to top:
 *  1. the solid background color (always painted, so a transparent PNG still reads well)
 *  2. the picked background image, if there is one, at the configured opacity
 *  3. the current album art, if "use artwork background" is on and music is playing
 *  4. a scrim, so white text stays legible over a bright photo
 *
 * This composable is purely decorative and never handles input — the parent Box
 * keeps ownership of every gesture.
 */
@Composable
fun IslandBackgroundLayer(
    settings: SmartIslandSettings,
    mode: IslandMode,
    artwork: Bitmap?,
    modifier: Modifier = Modifier
) {
    val backgroundColor = Color(settings.islandBackgroundColor)

    val customBitmap by produceState<Bitmap?>(
        initialValue = null,
        settings.islandBackgroundImagePath
    ) {
        value = if (settings.islandBackgroundImagePath.isBlank()) {
            null
        } else {
            withContext(Dispatchers.IO) {
                IslandBackgroundStore.load(settings.islandBackgroundImagePath)
            }
        }
    }

    val artworkBackground = artwork?.takeIf {
        settings.useArtworkBackground && mode == IslandMode.Music
    }

    Box(modifier = modifier.fillMaxSize().background(backgroundColor)) {
        customBitmap?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = settings.islandBackgroundImageAlpha,
                modifier = Modifier.fillMaxSize()
            )
        }

        artworkBackground?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = ARTWORK_BACKGROUND_ALPHA,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Only scrim when something was actually drawn on top of the base color;
        // a plain color background already has whatever contrast the user picked.
        if (customBitmap != null || artworkBackground != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = SCRIM_TOP_ALPHA),
                                Color.Black.copy(alpha = SCRIM_BOTTOM_ALPHA)
                            )
                        )
                    )
            )
        }
    }
}

private const val ARTWORK_BACKGROUND_ALPHA = 0.35f
private const val SCRIM_TOP_ALPHA = 0.25f
private const val SCRIM_BOTTOM_ALPHA = 0.45f
