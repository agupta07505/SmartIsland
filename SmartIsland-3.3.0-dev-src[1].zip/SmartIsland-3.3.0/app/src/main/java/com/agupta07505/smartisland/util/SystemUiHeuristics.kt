/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.util

import android.content.Context
import android.content.Intent

/**
 * Window-name heuristics used to answer two questions the platform will not
 * answer directly:
 *
 *  1. Is the quick settings / notification shade currently pulled down?
 *  2. Is the user sitting on their launcher, or inside some app?
 *
 * There is no public API for either, so we read the window class names that
 * AccessibilityService hands us. Class names differ across OEM skins, which is
 * why the matching is fragment-based and deliberately generous.
 */
object SystemUiHeuristics {

    private val SYSTEM_UI_PACKAGES = setOf(
        "com.android.systemui",
        "com.google.android.systemui",
        // OEM forks that ship their own SystemUI package
        "com.miui.systemui",
        "com.samsung.android.systemui",
        "com.oneplus.systemui",
        "com.oplus.systemui"
    )

    /**
     * Class-name fragments that show up when the shade or quick settings panel
     * is on screen. Matched case-insensitively against the full class name.
     */
    private val SHADE_CLASS_FRAGMENTS = listOf(
        "notificationshade",
        "notificationpanel",
        "quicksettings",
        "quickstatusbar",
        "qspanel",
        "qscontainer",
        "statusbarwindow",
        "shadewindow",
        "expandednotification",
        "controlpanel",
        "notificationcenter"
    )

    /** True when [packageName] is a SystemUI implementation. */
    fun isSystemUiPackage(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        return packageName in SYSTEM_UI_PACKAGES || packageName.endsWith(".systemui")
    }

    /**
     * True when the window described by [packageName] / [className] looks like
     * the pulled-down shade or quick settings panel.
     */
    fun isShadeWindow(packageName: String?, className: String?): Boolean {
        if (!isSystemUiPackage(packageName)) return false
        val normalized = className?.lowercase().orEmpty()
        if (normalized.isBlank()) return false
        return SHADE_CLASS_FRAGMENTS.any { normalized.contains(it) }
    }

    /**
     * True when [packageName] is one of the recognised home / launcher packages
     * for this device. [homePackages] normally comes from [resolveHomePackages].
     */
    fun isLauncherPackage(packageName: String?, homePackages: Set<String>): Boolean {
        if (packageName.isNullOrBlank()) return false
        return packageName in homePackages
    }

    /**
     * Every package on the device that can act as the home screen, so switching
     * launchers does not silently break the "hide inside app" rule.
     */
    fun resolveHomePackages(context: Context): Set<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val packages = runCatchingLogged(TAG, "Failed to resolve home packages") {
            context.packageManager
                .queryIntentActivities(intent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        }.orEmpty()

        // The recents / overview surface lives in SystemUI or the launcher itself;
        // treat both as "not inside an app" so the island does not flicker there.
        return packages + SYSTEM_UI_PACKAGES
    }

    private const val TAG = "SystemUiHeuristics"
}
