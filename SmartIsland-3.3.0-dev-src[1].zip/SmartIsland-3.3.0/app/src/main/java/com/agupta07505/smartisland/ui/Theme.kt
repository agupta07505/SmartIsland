/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.agupta07505.smartisland.data.SmartIslandSettings

/**
 * Material 3 theme for the settings app.
 *
 * Two things changed in 3.3:
 *  - the palettes are now complete M3 schemes (container/on-container roles
 *    included) instead of four hand-picked colours, so components like
 *    FilledTonalButton and Card stop falling back to defaults that clash;
 *  - Material You dynamic colour is supported on Android 12+ and is on by
 *    default, with a setting to turn it off for people who prefer the brand look.
 */
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF0B2A6B),
    secondary = Color(0xFF0891B2),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF06333D),
    tertiary = Color(0xFF7C3AED),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF3E8FF),
    onTertiaryContainer = Color(0xFF2E1065),
    error = Color(0xFFDC2626),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF111827),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE8EBF0),
    onSurfaceVariant = Color(0xFF4B5563),
    outline = Color(0xFF9CA3AF),
    outlineVariant = Color(0xFFD1D5DB),
    inverseSurface = Color(0xFF1F2937),
    inverseOnSurface = Color(0xFFF3F4F6)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF7CA9FF),
    onPrimary = Color(0xFF0B2A6B),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF67E8F9),
    onSecondary = Color(0xFF06333D),
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = Color(0xFFC084FC),
    onTertiary = Color(0xFF2E1065),
    tertiaryContainer = Color(0xFF581C87),
    onTertiaryContainer = Color(0xFFF3E8FF),
    error = Color(0xFFFCA5A5),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2),
    background = Color(0xFF0F141C),
    onBackground = Color(0xFFE5E7EB),
    surface = Color(0xFF161C26),
    onSurface = Color(0xFFE5E7EB),
    surfaceVariant = Color(0xFF232B37),
    onSurfaceVariant = Color(0xFFAAB2BF),
    outline = Color(0xFF5B6472),
    outlineVariant = Color(0xFF39424F),
    inverseSurface = Color(0xFFE5E7EB),
    inverseOnSurface = Color(0xFF1F2937)
)

/**
 * Slightly tightened M3 type scale — the defaults are generous for a settings
 * screen made almost entirely of two-line rows.
 */
private val SmartIslandTypography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            lineHeight = 32.sp
        ),
        titleMedium = base.titleMedium.copy(
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp
        ),
        labelLarge = base.labelLarge.copy(
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.6.sp
        ),
        bodySmall = TextStyle(
            fontSize = 13.sp,
            lineHeight = 18.sp,
            fontWeight = FontWeight.Normal
        )
    )
}

@Composable
fun SmartIslandTheme(
    themeMode: String = SmartIslandSettings.THEME_SYSTEM,
    dynamicColor: Boolean = true,
    darkTheme: Boolean = resolveDarkTheme(themeMode),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val supportsDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    val colorScheme = when {
        dynamicColor && supportsDynamic && darkTheme -> dynamicDarkColorScheme(context)
        dynamicColor && supportsDynamic -> dynamicLightColorScheme(context)
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SmartIslandTypography,
        content = content
    )
}

@Composable
private fun resolveDarkTheme(themeMode: String): Boolean = when (themeMode) {
    SmartIslandSettings.THEME_LIGHT -> false
    SmartIslandSettings.THEME_DARK -> true
    else -> isSystemInDarkTheme()
}
