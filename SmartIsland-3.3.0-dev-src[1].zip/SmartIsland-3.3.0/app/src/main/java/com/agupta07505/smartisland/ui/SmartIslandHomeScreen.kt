/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import com.agupta07505.smartisland.util.runCatchingLogged
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Feedback
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agupta07505.smartisland.R
import com.agupta07505.smartisland.data.INotificationRepository
import com.agupta07505.smartisland.data.SmartIslandSettings
import com.agupta07505.smartisland.data.SmartIslandSettingsRepository
import com.agupta07505.smartisland.di.SmartIslandRepositories
import com.agupta07505.smartisland.model.IslandMode
import android.widget.Toast
import com.agupta07505.smartisland.service.SmartIslandNotificationListenerService
import com.agupta07505.smartisland.service.SmartIslandOverlayService
import com.agupta07505.smartisland.util.ShizukuManager
import com.agupta07505.smartisland.util.safeStartActivity
import com.agupta07505.smartisland.util.SystemServiceRecovery
import com.agupta07505.smartisland.ui.sections.AboutSection
import com.agupta07505.smartisland.ui.sections.AppShortcutsSection
import com.agupta07505.smartisland.ui.sections.CustomizationsSection
import com.agupta07505.smartisland.ui.sections.HeaderSection
import com.agupta07505.smartisland.ui.sections.NotificationsAndPrivacySection
import com.agupta07505.smartisland.ui.sections.PermissionsSection
import com.agupta07505.smartisland.ui.sections.PositionsSection
import com.agupta07505.smartisland.ui.sections.SupportSection
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Gesture
import com.agupta07505.smartisland.ui.sections.GesturesSection
import kotlinx.coroutines.launch
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.Button
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.rounded.People
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.draw.clip

private enum class HomeSection {
    Permissions,
    AppShortcuts,
    Positions,
    Customizations,
    NotificationsPrivacy,
    Gestures,
    Support,
    About
}

private enum class MainDestination {
    Home,
    Settings
}

@SuppressLint("BatteryLife")
@Composable
fun SmartIslandHomeScreen(
    repository: SmartIslandSettingsRepository? = null,
    notificationRepository: INotificationRepository? = null
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val resolvedRepository = remember(repository, context) {
        repository ?: runCatching {
            SmartIslandRepositories.settingsRepository(context)
        }.getOrElse {
            SmartIslandSettingsRepository(context.applicationContext)
        }
    }
    val resolvedNotificationRepository = remember(notificationRepository, context) {
        notificationRepository ?: runCatching {
            SmartIslandRepositories.notificationRepository(context)
        }.getOrNull()
    }
    
    val settings by resolvedRepository.settings.collectAsStateWithLifecycle(initialValue = SmartIslandSettings.Default)
    val scope = rememberCoroutineScope()

    var showWelcomeDialog by remember { mutableStateOf(false) }

    // BUG FIX: the previous LaunchedEffect fired on every launch because
    // collectAsStateWithLifecycle(initialValue = SmartIslandSettings.Default) emits the
    // Default (welcomeDialogShown = false) on the first frame, force-showing the dialog
    // even after the user already dismissed it. Here we wait for the REAL persisted value
    // before deciding, so the dialog appears exactly once (until uninstall/reinstall).
    LaunchedEffect(Unit) {
        if (!resolvedRepository.isWelcomeDialogShown()) {
            showWelcomeDialog = true
        }
    }

    if (showWelcomeDialog) {
        WelcomeDialog(
            onDismiss = {
                showWelcomeDialog = false
                scope.launch {
                    resolvedRepository.setWelcomeDialogShown(true)
                }
            },
            onStarClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/agupta07505/SmartIsland"))
                runCatching {
                    context.startActivity(intent)
                }.onFailure {
                    android.widget.Toast.makeText(context, "Cannot open link", android.widget.Toast.LENGTH_SHORT).show()
                }
            },
            onJoinCommunityClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://telegram.me/SmartIslandApp"))
                runCatching {
                    context.startActivity(intent)
                }.onFailure {
                    android.widget.Toast.makeText(context, "Cannot open link", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    val isDark = isSystemInDarkTheme()
    val permissionsBg = if (isDark) Color(0xFF1E1B4B) else Color(0xFFE0E7FF)
    val permissionsTint = if (isDark) Color(0xFF818CF8) else Color(0xFF4F46E5)
    
    val positionsBg = if (isDark) Color(0xFF064E3B) else Color(0xFFD1FAE5)
    val positionsTint = if (isDark) Color(0xFF34D399) else Color(0xFF059669)
    
    val supportBg = if (isDark) Color(0xFF78350F) else Color(0xFFFEF3C7)
    val supportTint = if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706)
    
    val aboutBg = if (isDark) Color(0xFF581C87) else Color(0xFFF3E8FF)
    val aboutTint = if (isDark) Color(0xFFC084FC) else Color(0xFF7C3AED)
    val customizationsBg = if (isDark) Color(0xFF1E3A8A) else Color(0xFFDBEAFE)
    val customizationsTint = if (isDark) Color(0xFF3B82F6) else Color(0xFF1D4ED8)
    val shortcutsBg = if (isDark) Color(0xFF164E63) else Color(0xFFCFFAFE)
    val shortcutsTint = if (isDark) Color(0xFF22D3EE) else Color(0xFF0891B2)
    val privacyBg = if (isDark) Color(0xFF7F1D1D) else Color(0xFFFFE4E6)
    val privacyTint = if (isDark) Color(0xFFFB7185) else Color(0xFFE11D48)
    val gesturesBg = if (isDark) Color(0xFF311B92) else Color(0xFFEDE7F6)
    val gesturesTint = if (isDark) Color(0xFFB39DDB) else Color(0xFF512DA8)
    var overlayGranted by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }
    var notificationGranted by remember { mutableStateOf(isNotificationListenerEnabled(context)) }
    var batteryIgnored by remember { mutableStateOf(isBatteryOptimizationIgnored(context)) }

    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = isAccessibilityServiceEnabled(context)
                notificationGranted = isNotificationListenerEnabled(context)
                batteryIgnored = isBatteryOptimizationIgnored(context)
                // A force-stop can leave a system-managed service temporarily disconnected.
                // Preserve the user's preference and ask Android to reconnect instead of
                // persisting a false value that would keep the island off after rebinding.
                SystemServiceRecovery.requestRecovery(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var selectedDestination by remember { mutableStateOf(MainDestination.Home) }
    var activeSection by remember { mutableStateOf<HomeSection?>(null) }
    var transitionDirection by remember { mutableStateOf(1) } // 1 = forward, -1 = backward
    val homeScrollState = rememberScrollState()
    val settingsScrollState = rememberScrollState()

    BackHandler(
        enabled = activeSection != null || selectedDestination == MainDestination.Settings
    ) {
        if (activeSection != null) {
            transitionDirection = -1
            activeSection = null
        } else {
            selectedDestination = MainDestination.Home
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            SmartIslandBottomBar(
                selectedDestination = selectedDestination,
                onDestinationSelected = { destination ->
                    selectedDestination = destination
                    activeSection = null
                    transitionDirection = if (destination == MainDestination.Settings) 1 else -1
                }
            )
        }
    ) { scaffoldPadding ->
        AnimatedContent(
            targetState = activeSection,
            modifier = Modifier.padding(scaffoldPadding),
            transitionSpec = {
                if (transitionDirection == 1) {
                    (slideInHorizontally(initialOffsetX = { it }) + fadeIn())
                        .togetherWith(slideOutHorizontally(targetOffsetX = { -it }) + fadeOut())
                } else {
                    (slideInHorizontally(initialOffsetX = { -it }) + fadeIn())
                        .togetherWith(slideOutHorizontally(targetOffsetX = { it }) + fadeOut())
                }
            },
            label = "SectionTransition"
        ) { targetSection ->
            if (targetSection == null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .verticalScroll(
                            if (selectedDestination == MainDestination.Home) {
                                homeScrollState
                            } else {
                                settingsScrollState
                            }
                        )
                        .padding(
                            start = 20.dp,
                            end = 20.dp,
                            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 16.dp,
                            bottom = 24.dp
                        ),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val canEnable = overlayGranted && notificationGranted && batteryIgnored

                    if (selectedDestination == MainDestination.Home) {
                        HeaderSection()

                        Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.enable_smart_island),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (canEnable)
                                        stringResource(R.string.overlay_ready)
                                    else
                                        "Required: grant Accessibility, Notification access, and Battery optimization (No restrictions) to enable Smart Island.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 16.sp
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Switch(
                                checked = settings.enabled,
                                enabled = canEnable || settings.enabled,
                                onCheckedChange = { turnOn ->
                                    if (turnOn) {
                                        SystemServiceRecovery.requestRecovery(context)
                                    }
                                    scope.launch { resolvedRepository.setEnabled(turnOn) }
                                }
                            )
                        }
                        if (!canEnable) {
                            androidx.compose.material3.HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                thickness = 1.dp
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { transitionDirection = 1; activeSection = HomeSection.Permissions }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Set up required permissions →",
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Category 1: Quick Testing
                CategoryHeader("QUICK TESTING")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = stringResource(R.string.quick_test_controls),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                ElevatedButton(
                                    onClick = { resolvedNotificationRepository?.showDemo(IslandMode.Notification) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Notifications, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.btn_notify), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                                ElevatedButton(
                                    onClick = { resolvedNotificationRepository?.showDemo(IslandMode.IncomingCall) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.btn_call), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                ElevatedButton(
                                    onClick = { resolvedNotificationRepository?.showDemo(IslandMode.Music) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.btn_music), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                                ElevatedButton(
                                    onClick = { resolvedNotificationRepository?.showDemo(IslandMode.Battery) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.btn_battery), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            OutlinedButton(
                                onClick = { resolvedNotificationRepository?.clearTestNotifications() },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
                                )
                            ) {
                                Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.btn_clear_test), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                    } else {
                        SettingsHeader()

                CategoryHeader("SETUP")

                SectionRow(
                    title = "Permissions & setup",
                    description = "Manage the system access Smart Island needs",
                    icon = Icons.Rounded.Lock,
                    iconBgColor = permissionsBg,
                    iconTint = permissionsTint,
                    statusText = if (overlayGranted && notificationGranted && batteryIgnored) stringResource(R.string.status_active) else stringResource(R.string.status_action_required),
                    statusColor = if (overlayGranted && notificationGranted && batteryIgnored) Color(0xFF0F9F6E) else Color(0xFFE88C25),
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.Permissions
                    }
                )

                CategoryHeader("PERSONALIZATION")

                SectionRow(
                    title = "Island layout",
                    description = "Adjust the size, position, and corner radius",
                    icon = Icons.Rounded.Refresh,
                    iconBgColor = positionsBg,
                    iconTint = positionsTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.Positions
                    }
                )

                SectionRow(
                    title = "Colors & appearance",
                    description = "Personalize battery, notification, and visualizer colors",
                    icon = Icons.Rounded.Palette,
                    iconBgColor = customizationsBg,
                    iconTint = customizationsTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.Customizations
                    }
                )

                CategoryHeader("CONTENT & INTERACTIONS")

                SectionRow(
                    title = "Notifications & privacy",
                    description = "Control lock screen visibility, privacy, and quick actions",
                    icon = Icons.Rounded.Notifications,
                    iconBgColor = privacyBg,
                    iconTint = privacyTint,
                    statusText = if (settings.showOnLockScreen) "Lock screen on" else "Lock screen off",
                    statusColor = privacyTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.NotificationsPrivacy
                    }
                )

                SectionRow(
                    title = "App shortcuts",
                    description = "Choose apps available whenever the expanded island is empty",
                    icon = Icons.Rounded.Apps,
                    iconBgColor = shortcutsBg,
                    iconTint = shortcutsTint,
                    statusText = when {
                        settings.shortcutPackages.isNotEmpty() -> "${settings.shortcutPackages.size} selected"
                        settings.showRecentApps -> "Recent apps enabled"
                        else -> "Set up"
                    },
                    statusColor = shortcutsTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.AppShortcuts
                    }
                )

                SectionRow(
                    title = "Gesture guide",
                    description = "Learn how to interact with the Smart Island",
                    icon = Icons.Rounded.Gesture,
                    iconBgColor = gesturesBg,
                    iconTint = gesturesTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.Gestures
                    }
                )

                CategoryHeader("HELP & ABOUT")

                SectionRow(
                    title = "Help & feedback",
                    description = "Get support, report an issue, or suggest an improvement",
                    icon = Icons.Rounded.Feedback,
                    iconBgColor = supportBg,
                    iconTint = supportTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.Support
                    }
                )

                SectionRow(
                    title = "About Smart Island",
                    description = "Version, contributors, community, and project links",
                    icon = Icons.Rounded.Info,
                    iconBgColor = aboutBg,
                    iconTint = aboutTint,
                    onClick = {
                        transitionDirection = 1
                        activeSection = HomeSection.About
                    }
                )

                Spacer(Modifier.height(16.dp))
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.made_by),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                Spacer(Modifier.height(12.dp))
                    }
            }
        } else {
            when (targetSection) {
                HomeSection.Permissions -> {
                    SectionDetailScreen(
                        title = "Permissions & setup",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        PermissionsSection(
                            overlayGranted = overlayGranted,
                            notificationGranted = notificationGranted,
                            batteryIgnored = batteryIgnored,
                            onOverlayClick = {
                                if (ShizukuManager.hasPermission()) {
                                    scope.launch {
                                        val result = ShizukuManager.grantAccessibility(context)
                                        result.onSuccess {
                                            Toast.makeText(context, "Accessibility permission granted via Shizuku!", Toast.LENGTH_SHORT).show()
                                        }.onFailure { err ->
                                            Toast.makeText(context, "Shizuku error: ${err.localizedMessage}", Toast.LENGTH_SHORT).show()
                                        }
                                        overlayGranted = isAccessibilityServiceEnabled(context)
                                        notificationGranted = isNotificationListenerEnabled(context)
                                        batteryIgnored = isBatteryOptimizationIgnored(context)
                                        SystemServiceRecovery.requestRecovery(context)
                                    }
                                } else {
                                    context.safeStartActivity(
                                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                                        "Cannot open Accessibility settings on this device."
                                    )
                                }
                            },
                            onNotificationClick = {
                                if (ShizukuManager.hasPermission()) {
                                    scope.launch {
                                        val result = ShizukuManager.grantNotificationListener(context)
                                        result.onSuccess {
                                            Toast.makeText(context, "Notification access granted via Shizuku!", Toast.LENGTH_SHORT).show()
                                        }.onFailure { err ->
                                            Toast.makeText(context, "Shizuku error: ${err.localizedMessage}", Toast.LENGTH_SHORT).show()
                                        }
                                        overlayGranted = isAccessibilityServiceEnabled(context)
                                        notificationGranted = isNotificationListenerEnabled(context)
                                        batteryIgnored = isBatteryOptimizationIgnored(context)
                                        SystemServiceRecovery.requestRecovery(context)
                                    }
                                } else {
                                    val detailIntent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS").apply {
                                        val component = ComponentName(context, SmartIslandNotificationListenerService::class.java)
                                        putExtra("android.provider.extra.NOTIFICATION_LISTENER_COMPONENT_NAME", component.flattenToString())
                                    }
                                    context.safeStartActivity(
                                        detailIntent,
                                        errorMessage = "Cannot open Notification access settings on this device.",
                                        fallbackIntent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    )
                                }
                            },
                            onBatteryClick = {
                                context.safeStartActivity(
                                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                        .setData(Uri.parse("package:${context.packageName}")),
                                    errorMessage = "Cannot open Battery optimization settings on this device.",
                                    fallbackIntent = Intent(
                                        Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
                                    )
                                )
                            },
                            onRefreshPermissions = {
                                overlayGranted = isAccessibilityServiceEnabled(context)
                                notificationGranted = isNotificationListenerEnabled(context)
                                batteryIgnored = isBatteryOptimizationIgnored(context)
                            }
                        )
                    }
                }
                HomeSection.Positions -> {
                    SectionDetailScreen(
                        title = stringResource(R.string.sec_positions),
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        PositionsSection(settings = settings, repository = resolvedRepository)
                    }
                }
                HomeSection.AppShortcuts -> {
                    SectionDetailScreen(
                        title = "App shortcuts",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        AppShortcutsSection(settings = settings, repository = resolvedRepository)
                    }
                }
                HomeSection.Customizations -> {
                    SectionDetailScreen(
                        title = "Colors & appearance",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        CustomizationsSection(settings = settings, repository = resolvedRepository)
                    }
                }
                HomeSection.NotificationsPrivacy -> {
                    SectionDetailScreen(
                        title = "Notifications & privacy",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        NotificationsAndPrivacySection(
                            settings = settings,
                            repository = resolvedRepository
                        )
                    }
                }
                HomeSection.Gestures -> {
                    SectionDetailScreen(
                        title = "Gesture guide",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        GesturesSection()
                    }
                }
                HomeSection.Support -> {
                    SectionDetailScreen(
                        title = "Help & feedback",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        SupportSection()
                    }
                }
                HomeSection.About -> {
                    SectionDetailScreen(
                        title = "About Smart Island",
                        onBack = {
                            transitionDirection = -1
                            activeSection = null
                        }
                    ) {
                        AboutSection()
                    }
                }
            }
        }
    }
}
}

@Composable
private fun SmartIslandBottomBar(
    selectedDestination: MainDestination,
    onDestinationSelected: (MainDestination) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        NavigationBarItem(
            selected = selectedDestination == MainDestination.Home,
            onClick = { onDestinationSelected(MainDestination.Home) },
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = selectedDestination == MainDestination.Settings,
            onClick = { onDestinationSelected(MainDestination.Settings) },
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = "Settings"
                )
            },
            label = { Text("Settings") }
        )
    }
}

@Composable
private fun SettingsHeader() {
    Text(
        text = "Settings",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
    )
}

@Composable
private fun CategoryHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp, start = 4.dp)
    )
}

@Composable
private fun SectionRow(
    title: String,
    description: String,
    icon: ImageVector,
    iconBgColor: Color,
    iconTint: Color,
    statusText: String? = null,
    statusColor: Color? = null,
    onClick: () -> Unit
) {
    val defaultStatusColor = MaterialTheme.colorScheme.onSurfaceVariant
    val resolvedStatusColor = statusColor ?: defaultStatusColor
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(iconBgColor, shape = RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
                if (statusText != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .background(resolvedStatusColor.copy(alpha = 0.12f), shape = RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = statusText,
                            color = resolvedStatusColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun SectionDetailScreen(
    title: String,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp,
                bottom = 24.dp
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        content()
    }
}

private fun isNotificationListenerEnabled(context: Context): Boolean {
    val enabled = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
    )
    return enabled?.split(":")?.any {
        ComponentName.unflattenFromString(it)?.packageName == context.packageName
    } == true
}

@Composable
private fun WelcomeDialog(
    onDismiss: () -> Unit,
    onStarClick: () -> Unit,
    onJoinCommunityClick: () -> Unit
) {
    val context = LocalContext.current
    val appIcon = remember(context) {
        runCatchingLogged("WelcomeDialog", "Failed to get app icon") {
            val drawable = context.packageManager.getApplicationIcon(context.packageName)
            val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 144
            val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 144
            val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            drawable.setBounds(0, 0, width, height)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (appIcon != null) {
                    Image(
                        bitmap = appIcon,
                        contentDescription = "Smart Island Logo",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SI", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }

                Text(
                    text = "Welcome to Smart Island",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "A privacy-first, custom floating overlay experience for Android. No ads, no tracking, no internet permission.\n\nSupport us by starring the repo and joining our community!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onStarClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GithubIcon(tint = MaterialTheme.colorScheme.onSecondary)
                        Text(
                            "Star on GitHub",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondary
                        )
                    }
                }

                androidx.compose.material3.OutlinedButton(
                    onClick = onJoinCommunityClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.People,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            "Join Telegram Community",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                ElevatedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Get Started", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun GithubIcon(tint: Color = Color.Black) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val scaleX = size.width / 24f
        val scaleY = size.height / 24f
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(12f * scaleX, 2f * scaleY)
            cubicTo(6.477f * scaleX, 2f * scaleY, 2f * scaleX, 6.477f * scaleX, 2f * scaleX, 12f * scaleY)
            cubicTo(2f * scaleX, 16.42f * scaleY, 4.865f * scaleX, 20.166f * scaleY, 8.839f * scaleX, 21.489f * scaleY)
            cubicTo(9.339f * scaleX, 21.581f * scaleY, 9.521f * scaleX, 21.272f * scaleY, 9.521f * scaleX, 21.007f * scaleY)
            cubicTo(9.521f * scaleX, 20.77f * scaleY, 9.513f * scaleX, 20.141f * scaleY, 9.508f * scaleX, 19.307f * scaleY)
            cubicTo(6.726f * scaleX, 19.91f * scaleY, 6.139f * scaleX, 17.97f * scaleY, 6.139f * scaleX, 17.97f * scaleY)
            cubicTo(5.685f * scaleX, 16.814f * scaleY, 5.029f * scaleX, 16.506f * scaleY, 5.029f * scaleX, 16.506f * scaleY)
            cubicTo(4.121f * scaleX, 15.886f * scaleY, 5.098f * scaleX, 15.898f * scaleY, 5.098f * scaleX, 15.898f * scaleY)
            cubicTo(6.101f * scaleX, 15.968f * scaleY, 6.629f * scaleX, 16.928f * scaleY, 6.629f * scaleX, 16.928f * scaleY)
            cubicTo(7.521f * scaleX, 18.457f * scaleY, 8.97f * scaleX, 18.015f * scaleY, 9.539f * scaleX, 17.759f * scaleY)
            cubicTo(9.631f * scaleX, 17.113f * scaleY, 9.889f * scaleX, 16.673f * scaleY, 10.175f * scaleX, 16.423f * scaleY)
            cubicTo(7.955f * scaleX, 16.17f * scaleY, 5.62f * scaleX, 15.313f * scaleY, 5.62f * scaleX, 11.48f * scaleY)
            cubicTo(5.62f * scaleX, 10.389f * scaleY, 6.01f * scaleX, 9.496f * scaleY, 6.649f * scaleX, 8.797f * scaleY)
            cubicTo(6.546f * scaleX, 8.544f * scaleY, 6.203f * scaleX, 7.527f * scaleY, 6.747f * scaleX, 6.15f * scaleY)
            cubicTo(6.747f * scaleX, 6.15f * scaleY, 7.587f * scaleX, 5.881f * scaleY, 9.497f * scaleX, 7.175f * scaleY)
            cubicTo(10.295f * scaleX, 6.953f * scaleY, 11.15f * scaleX, 6.842f * scaleY, 12f * scaleX, 6.838f * scaleY)
            cubicTo(12.85f * scaleX, 6.842f * scaleY, 13.705f * scaleX, 6.953f * scaleY, 14.503f * scaleX, 7.175f * scaleY)
            cubicTo(16.413f * scaleX, 5.881f * scaleY, 17.253f * scaleX, 6.15f * scaleY, 17.253f * scaleX, 6.15f * scaleY)
            cubicTo(17.797f * scaleX, 7.527f * scaleY, 17.454f * scaleX, 8.544f * scaleY, 17.351f * scaleX, 8.797f * scaleY)
            cubicTo(17.99f * scaleX, 9.496f * scaleY, 18.38f * scaleX, 10.389f * scaleY, 18.38f * scaleX, 11.48f * scaleY)
            cubicTo(18.38f * scaleX, 15.323f * scaleY, 16.041f * scaleX, 16.168f * scaleY, 13.813f * scaleX, 16.415f * scaleY)
            cubicTo(14.172f * scaleX, 16.724f * scaleY, 14.491f * scaleX, 17.334f * scaleY, 14.491f * scaleX, 18.267f * scaleY)
            cubicTo(14.491f * scaleX, 19.603f * scaleY, 14.479f * scaleX, 20.682f * scaleY, 14.479f * scaleX, 21.01f * scaleY)
            cubicTo(14.479f * scaleX, 21.277f * scaleY, 14.659f * scaleX, 21.589f * scaleY, 15.167f * scaleX, 21.489f * scaleY)
            cubicTo(19.141f * scaleX, 20.16f * scaleY, 22f * scaleX, 12f * scaleY, 22f * scaleX, 12f * scaleY)
            cubicTo(22f * scaleX, 6.477f * scaleY, 17.523f * scaleX, 2f * scaleY, 12f * scaleX, 2f * scaleY)
            close()
        }
        drawPath(path, color = tint)
    }
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val expectedComponentName = ComponentName(context, com.agupta07505.smartisland.service.SmartIslandOverlayService::class.java)
    val enabledServicesSetting = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val colonSplitter = android.text.TextUtils.SimpleStringSplitter(':')
    colonSplitter.setString(enabledServicesSetting)
    while (colonSplitter.hasNext()) {
        val componentNameString = colonSplitter.next()
        val enabledService = ComponentName.unflattenFromString(componentNameString)
        if (enabledService != null && enabledService == expectedComponentName) {
            return true
        }
    }
    return false
}

private fun isBatteryOptimizationIgnored(context: Context): Boolean {
    if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return true
    val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

@Preview(showBackground = true, name = "Light Mode")
@Composable
fun SmartIslandHomeScreenLightPreview() {
    SmartIslandTheme(darkTheme = false) {
        SmartIslandHomeScreen()
    }
}

@Preview(showBackground = true, name = "Dark Mode")
@Composable
fun SmartIslandHomeScreenDarkPreview() {
    SmartIslandTheme(darkTheme = true) {
        SmartIslandHomeScreen()
    }
}
