/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.agupta07505.smartisland.data.AppShortcutProvider
import com.agupta07505.smartisland.data.LaunchableApp
import com.agupta07505.smartisland.data.ShelfRepository
import com.agupta07505.smartisland.model.IslandMode
import com.agupta07505.smartisland.model.IslandNotification
import com.agupta07505.smartisland.model.ShelfItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun OverlayIsland(
    viewModel: IslandViewModel,
    shelfRepository: ShelfRepository,
    statusBarHeight: Float,
    onOpenNotification: (IslandNotification) -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenFloatingWindow: () -> Unit,
    onOpenMediaApp: (IslandNotification) -> Unit,
    onShareShelfItem: (ShelfItem) -> Unit,
    onCopyShelfItem: (ShelfItem) -> Unit,
    onRemoveShelfItem: (ShelfItem) -> Unit,
    onClearShelf: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val expanded by viewModel.expanded.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val selectedIndex by viewModel.selectedIndex.collectAsState()
    val isLocked by viewModel.isLocked.collectAsState()
    val shelfItems by shelfRepository.items.collectAsState()
    val context = LocalContext.current

    val isContentRedacted = isLocked && settings.lockScreenPrivacy == "AppIconOnly"
    val processedNotifications = remember(notifications, isContentRedacted) {
        if (isContentRedacted) {
            notifications
                // Captures can contain anything; never stage them behind a lock screen.
                .filterNot { it.mode == IslandMode.Shelf }
                .map { notif ->
                    if (notif.mode == IslandMode.Notification) {
                        notif.copy(
                            title = notif.appName,
                            text = "Contents hidden",
                            actionIntents = emptyList()
                        )
                    } else {
                        notif
                    }
                }
        } else {
            notifications
        }
    }

    val selectedApps = remember(settings.shortcutPackages) {
        AppShortcutProvider.selectedApps(context, settings.shortcutPackages)
    }
    val launcherApps by produceState<List<LaunchableApp>?>(
        initialValue = when {
            selectedApps.isNotEmpty() -> selectedApps
            settings.shortcutPackages.isEmpty() && !settings.showRecentApps -> emptyList()
            !AppShortcutProvider.hasUsageAccess(context) -> emptyList()
            else -> null
        },
        settings.shortcutPackages,
        settings.showRecentApps
    ) {
        value = withContext(Dispatchers.IO) {
            AppShortcutProvider.shortcuts(
                context = context,
                selectedPackages = settings.shortcutPackages,
                includeRecent = settings.showRecentApps
            )
        }
    }

    IslandOverlayView(
        settings = settings,
        expanded = expanded,
        notifications = processedNotifications,
        selectedIndex = selectedIndex,
        launcherApps = launcherApps,
        onPageSelected = { index -> viewModel.setSelectedNotificationIndex(index) },
        onOpenNotification = onOpenNotification,
        onLaunchApp = onLaunchApp,
        onToggleExpanded = { viewModel.toggleExpanded() },
        onDismissNotification = { viewModel.dismissCurrentNotification() },
        onOpenFloatingWindow = onOpenFloatingWindow,
        onOpenMediaApp = onOpenMediaApp,
        shelfItems = shelfItems,
        onShareShelfItem = onShareShelfItem,
        onCopyShelfItem = onCopyShelfItem,
        onRemoveShelfItem = onRemoveShelfItem,
        onClearShelf = onClearShelf,
        statusBarHeight = statusBarHeight,
        modifier = modifier
    )
}
