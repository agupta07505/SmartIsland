/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.data

data class SmartIslandSettings(
    val enabled: Boolean = false,
    val width: Float = 112f,
    val height: Float = 34f,
    val xOffset: Float = 0f,
    val yOffset: Float = 12f,
    val cornerRadius: Float = 22f,
    val batteryColor: Long = 0xFF10B981L,
    val notificationDotColor: Long = 0xFF2563EBL,
    val musicVisualizerColor: Long = 0xFFFF6B9AL,
    val shortcutPackages: Set<String> = emptySet(),
    val showRecentApps: Boolean = false,
    val welcomeDialogShown: Boolean = false,
    val showOnLockScreen: Boolean = false,
    val lockScreenPrivacy: String = "AppIconOnly",
    val showNotificationActions: Boolean = true,
    val hideFromNotificationShade: Boolean = false,

    // ── Island background (v3.3) ──────────────────────────────────────────────
    /** Solid ARGB fill painted behind the island. Defaults to opaque black. */
    val islandBackgroundColor: Long = 0xFF000000L,
    /**
     * Absolute path of a user-picked image copied into the app's private files
     * directory. Empty means "no image, use islandBackgroundColor".
     */
    val islandBackgroundImagePath: String = "",
    /** Opacity of the background image, 0f..1f. The color shows through below it. */
    val islandBackgroundImageAlpha: Float = 1f,
    /** Use the currently playing album art as a dimmed island background. */
    val useArtworkBackground: Boolean = false,

    // ── Music (v3.3) ──────────────────────────────────────────────────────────
    /** Tapping the album art in the expanded music card opens the player app. */
    val openPlayerOnArtworkTap: Boolean = true,

    // ── Capture shelf (v3.3) ─────────────────────────────────────────────────
    /** Master switch for screenshot / clipboard capture handling. */
    val captureShelfEnabled: Boolean = false,
    /** Watch MediaStore for new screenshots. */
    val captureWatchScreenshots: Boolean = true,
    /** Watch the clipboard for copied text. */
    val captureWatchClipboard: Boolean = true,
    /**
     * "Shelf"      → captures land on the island shelf, user taps Share when ready.
     * "ShareSheet" → the Android share sheet opens immediately on capture.
     */
    val captureAction: String = CAPTURE_ACTION_SHELF,

    // ── Burst silencing (v3.3) ───────────────────────────────────────────────
    /** Stop popping the island open after N notifications from the same app. */
    val silenceBurstEnabled: Boolean = true,
    /** How many notifications from one app before the island stops auto-expanding. */
    val silenceBurstThreshold: Int = 3,

    // ── Visibility rules (v3.3) ──────────────────────────────────────────────
    /**
     * "Always"         → island is always on screen.
     * "OnNotification" → island only appears while it has something to show.
     */
    val visibilityMode: String = VISIBILITY_ALWAYS,
    /** Hide the island while the quick settings / notification shade is pulled down. */
    val hideOnQuickSettings: Boolean = true,
    /** Hide the island while any app other than the launcher is in the foreground. */
    val hideInsideApp: Boolean = false,

    // ── Appearance (v3.3) ────────────────────────────────────────────────────
    /** Material You dynamic color for the settings app (Android 12+). */
    val dynamicColorEnabled: Boolean = true,
    /** "System" | "Light" | "Dark" */
    val themeMode: String = THEME_SYSTEM
) {
    companion object {
        val Default = SmartIslandSettings()

        const val MIN_WIDTH = 76f
        const val MAX_WIDTH = 180f
        const val MIN_HEIGHT = 24f
        const val MAX_HEIGHT = 60f
        const val MIN_X_OFFSET = -140f
        const val MAX_X_OFFSET = 140f
        const val MIN_Y_OFFSET = 0f
        const val MAX_Y_OFFSET = 80f
        const val MIN_CORNER_RADIUS = 8f
        const val MAX_CORNER_RADIUS = 40f

        const val MIN_BACKGROUND_IMAGE_ALPHA = 0.1f
        const val MAX_BACKGROUND_IMAGE_ALPHA = 1f

        const val MIN_BURST_THRESHOLD = 2
        const val MAX_BURST_THRESHOLD = 10

        const val CAPTURE_ACTION_SHELF = "Shelf"
        const val CAPTURE_ACTION_SHARE_SHEET = "ShareSheet"
        val VALID_CAPTURE_ACTIONS = setOf(CAPTURE_ACTION_SHELF, CAPTURE_ACTION_SHARE_SHEET)

        const val VISIBILITY_ALWAYS = "Always"
        const val VISIBILITY_ON_NOTIFICATION = "OnNotification"
        val VALID_VISIBILITY_MODES = setOf(VISIBILITY_ALWAYS, VISIBILITY_ON_NOTIFICATION)

        const val THEME_SYSTEM = "System"
        const val THEME_LIGHT = "Light"
        const val THEME_DARK = "Dark"
        val VALID_THEME_MODES = setOf(THEME_SYSTEM, THEME_LIGHT, THEME_DARK)
    }
}
