/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.data

import android.content.Context
import android.util.Log
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.smartIslandDataStore by preferencesDataStore(
    name = "smart_island_settings",
    corruptionHandler = ReplaceFileCorruptionHandler {
        Log.e("SmartIslandSettings", "Settings were corrupted; restoring safe defaults")
        emptyPreferences()
    }
)

class SmartIslandSettingsRepository(private val context: Context) {
    private object Keys {
        val Enabled = booleanPreferencesKey("enabled")
        val Width = floatPreferencesKey("width")
        val Height = floatPreferencesKey("height")
        val XOffset = floatPreferencesKey("x_offset")
        val YOffset = floatPreferencesKey("y_offset")
        val CornerRadius = floatPreferencesKey("corner_radius")
        val BatteryColor = longPreferencesKey("battery_color")
        val NotificationDotColor = longPreferencesKey("notification_dot_color")
        val MusicVisualizerColor = longPreferencesKey("music_visualizer_color")
        val ShortcutPackages = stringSetPreferencesKey("shortcut_packages")
        val ShowRecentApps = booleanPreferencesKey("show_recent_apps")
        val WelcomeDialogShown = booleanPreferencesKey("welcome_dialog_shown")
        val ShowOnLockScreen = booleanPreferencesKey("show_on_lock_screen")
        val LockScreenPrivacy = stringPreferencesKey("lock_screen_privacy")
        val ShowNotificationActions = booleanPreferencesKey("show_notification_actions")
        val HideFromNotificationShade = booleanPreferencesKey("hide_from_notification_shade")

        // v3.3
        val IslandBackgroundColor = longPreferencesKey("island_background_color")
        val IslandBackgroundImagePath = stringPreferencesKey("island_background_image_path")
        val IslandBackgroundImageAlpha = floatPreferencesKey("island_background_image_alpha")
        val UseArtworkBackground = booleanPreferencesKey("use_artwork_background")
        val OpenPlayerOnArtworkTap = booleanPreferencesKey("open_player_on_artwork_tap")
        val CaptureShelfEnabled = booleanPreferencesKey("capture_shelf_enabled")
        val CaptureWatchScreenshots = booleanPreferencesKey("capture_watch_screenshots")
        val CaptureWatchClipboard = booleanPreferencesKey("capture_watch_clipboard")
        val CaptureAction = stringPreferencesKey("capture_action")
        val SilenceBurstEnabled = booleanPreferencesKey("silence_burst_enabled")
        val SilenceBurstThreshold = intPreferencesKey("silence_burst_threshold")
        val VisibilityMode = stringPreferencesKey("visibility_mode")
        val HideOnQuickSettings = booleanPreferencesKey("hide_on_quick_settings")
        val HideInsideApp = booleanPreferencesKey("hide_inside_app")
        val DynamicColorEnabled = booleanPreferencesKey("dynamic_color_enabled")
        val ThemeMode = stringPreferencesKey("theme_mode")
    }

    val settings: Flow<SmartIslandSettings> = context.smartIslandDataStore.data
        .catch { error ->
            if (error is IOException) {
                Log.e(TAG, "Unable to read settings; using safe defaults", error)
                emit(emptyPreferences())
            } else {
                throw error
            }
        }
        .map { prefs ->
            val defaults = SmartIslandSettings.Default
            SmartIslandSettings(
                enabled = prefs[Keys.Enabled] ?: defaults.enabled,
                width = validDimension(
                    prefs[Keys.Width],
                    defaults.width,
                    SmartIslandSettings.MIN_WIDTH,
                    SmartIslandSettings.MAX_WIDTH
                ),
                height = validDimension(
                    prefs[Keys.Height],
                    defaults.height,
                    SmartIslandSettings.MIN_HEIGHT,
                    SmartIslandSettings.MAX_HEIGHT
                ),
                xOffset = validDimension(
                    prefs[Keys.XOffset],
                    defaults.xOffset,
                    SmartIslandSettings.MIN_X_OFFSET,
                    SmartIslandSettings.MAX_X_OFFSET
                ),
                yOffset = validDimension(
                    prefs[Keys.YOffset],
                    defaults.yOffset,
                    SmartIslandSettings.MIN_Y_OFFSET,
                    SmartIslandSettings.MAX_Y_OFFSET
                ),
                cornerRadius = validDimension(
                    prefs[Keys.CornerRadius],
                    defaults.cornerRadius,
                    SmartIslandSettings.MIN_CORNER_RADIUS,
                    SmartIslandSettings.MAX_CORNER_RADIUS
                ),
                batteryColor = validColor(prefs[Keys.BatteryColor], defaults.batteryColor),
                notificationDotColor = validColor(
                    prefs[Keys.NotificationDotColor],
                    defaults.notificationDotColor
                ),
                musicVisualizerColor = validColor(
                    prefs[Keys.MusicVisualizerColor],
                    defaults.musicVisualizerColor
                ),
                shortcutPackages = prefs[Keys.ShortcutPackages]
                    ?.asSequence()
                    ?.filter { it.isNotBlank() && it.length <= MAX_PACKAGE_NAME_LENGTH }
                    ?.take(MAX_SHORTCUTS)
                    ?.toSet()
                    ?: defaults.shortcutPackages,
                showRecentApps = prefs[Keys.ShowRecentApps] ?: defaults.showRecentApps,
                welcomeDialogShown = prefs[Keys.WelcomeDialogShown] ?: defaults.welcomeDialogShown,
                showOnLockScreen = prefs[Keys.ShowOnLockScreen] ?: defaults.showOnLockScreen,
                lockScreenPrivacy = prefs[Keys.LockScreenPrivacy]
                    ?.takeIf { it in VALID_LOCK_SCREEN_PRIVACY_VALUES }
                    ?: defaults.lockScreenPrivacy,
                showNotificationActions = prefs[Keys.ShowNotificationActions]
                    ?: defaults.showNotificationActions,
                hideFromNotificationShade = prefs[Keys.HideFromNotificationShade]
                    ?: defaults.hideFromNotificationShade,

                // v3.3
                islandBackgroundColor = validColor(
                    prefs[Keys.IslandBackgroundColor],
                    defaults.islandBackgroundColor
                ),
                islandBackgroundImagePath = prefs[Keys.IslandBackgroundImagePath]
                    ?.takeIf { it.isNotBlank() && it.length <= MAX_PATH_LENGTH }
                    ?: defaults.islandBackgroundImagePath,
                islandBackgroundImageAlpha = validDimension(
                    prefs[Keys.IslandBackgroundImageAlpha],
                    defaults.islandBackgroundImageAlpha,
                    SmartIslandSettings.MIN_BACKGROUND_IMAGE_ALPHA,
                    SmartIslandSettings.MAX_BACKGROUND_IMAGE_ALPHA
                ),
                useArtworkBackground = prefs[Keys.UseArtworkBackground]
                    ?: defaults.useArtworkBackground,
                openPlayerOnArtworkTap = prefs[Keys.OpenPlayerOnArtworkTap]
                    ?: defaults.openPlayerOnArtworkTap,
                captureShelfEnabled = prefs[Keys.CaptureShelfEnabled]
                    ?: defaults.captureShelfEnabled,
                captureWatchScreenshots = prefs[Keys.CaptureWatchScreenshots]
                    ?: defaults.captureWatchScreenshots,
                captureWatchClipboard = prefs[Keys.CaptureWatchClipboard]
                    ?: defaults.captureWatchClipboard,
                captureAction = prefs[Keys.CaptureAction]
                    ?.takeIf { it in SmartIslandSettings.VALID_CAPTURE_ACTIONS }
                    ?: defaults.captureAction,
                silenceBurstEnabled = prefs[Keys.SilenceBurstEnabled]
                    ?: defaults.silenceBurstEnabled,
                silenceBurstThreshold = prefs[Keys.SilenceBurstThreshold]
                    ?.coerceIn(
                        SmartIslandSettings.MIN_BURST_THRESHOLD,
                        SmartIslandSettings.MAX_BURST_THRESHOLD
                    )
                    ?: defaults.silenceBurstThreshold,
                visibilityMode = prefs[Keys.VisibilityMode]
                    ?.takeIf { it in SmartIslandSettings.VALID_VISIBILITY_MODES }
                    ?: defaults.visibilityMode,
                hideOnQuickSettings = prefs[Keys.HideOnQuickSettings]
                    ?: defaults.hideOnQuickSettings,
                hideInsideApp = prefs[Keys.HideInsideApp] ?: defaults.hideInsideApp,
                dynamicColorEnabled = prefs[Keys.DynamicColorEnabled]
                    ?: defaults.dynamicColorEnabled,
                themeMode = prefs[Keys.ThemeMode]
                    ?.takeIf { it in SmartIslandSettings.VALID_THEME_MODES }
                    ?: defaults.themeMode
            )
        }

    suspend fun setEnabled(value: Boolean) = editSafely { it[Keys.Enabled] = value }
    suspend fun setWidth(value: Float) = editSafely {
        it[Keys.Width] = validDimension(
            value,
            SmartIslandSettings.Default.width,
            SmartIslandSettings.MIN_WIDTH,
            SmartIslandSettings.MAX_WIDTH
        )
    }
    suspend fun setHeight(value: Float) = editSafely {
        it[Keys.Height] = validDimension(
            value,
            SmartIslandSettings.Default.height,
            SmartIslandSettings.MIN_HEIGHT,
            SmartIslandSettings.MAX_HEIGHT
        )
    }
    suspend fun setXOffset(value: Float) = editSafely {
        it[Keys.XOffset] = validDimension(
            value,
            SmartIslandSettings.Default.xOffset,
            SmartIslandSettings.MIN_X_OFFSET,
            SmartIslandSettings.MAX_X_OFFSET
        )
    }
    suspend fun setYOffset(value: Float) = editSafely {
        it[Keys.YOffset] = validDimension(
            value,
            SmartIslandSettings.Default.yOffset,
            SmartIslandSettings.MIN_Y_OFFSET,
            SmartIslandSettings.MAX_Y_OFFSET
        )
    }
    suspend fun setCornerRadius(value: Float) = editSafely {
        it[Keys.CornerRadius] = validDimension(
            value,
            SmartIslandSettings.Default.cornerRadius,
            SmartIslandSettings.MIN_CORNER_RADIUS,
            SmartIslandSettings.MAX_CORNER_RADIUS
        )
    }
    suspend fun setBatteryColor(value: Long) = editSafely {
        it[Keys.BatteryColor] = validColor(value, SmartIslandSettings.Default.batteryColor)
    }
    suspend fun setNotificationDotColor(value: Long) = editSafely {
        it[Keys.NotificationDotColor] = validColor(
            value,
            SmartIslandSettings.Default.notificationDotColor
        )
    }
    suspend fun setMusicVisualizerColor(value: Long) = editSafely {
        it[Keys.MusicVisualizerColor] = validColor(
            value,
            SmartIslandSettings.Default.musicVisualizerColor
        )
    }
    suspend fun setShortcutPackages(value: Set<String>) = editSafely {
        it[Keys.ShortcutPackages] = value
            .asSequence()
            .filter { packageName ->
                packageName.isNotBlank() && packageName.length <= MAX_PACKAGE_NAME_LENGTH
            }
            .take(MAX_SHORTCUTS)
            .toSet()
    }
    suspend fun setShowRecentApps(value: Boolean) = editSafely {
        it[Keys.ShowRecentApps] = value
    }
    suspend fun setWelcomeDialogShown(value: Boolean) = editSafely {
        it[Keys.WelcomeDialogShown] = value
    }

    /**
     * Reads the REAL persisted value (awaits the first on-disk emission) instead of
     * relying on the SmartIslandSettings.Default placeholder that State flows emit on the
     * first frame. Used to decide whether the welcome dialog should show.
     */
    suspend fun isWelcomeDialogShown(): Boolean = settings.first().welcomeDialogShown

    suspend fun setShowOnLockScreen(value: Boolean) = editSafely {
        it[Keys.ShowOnLockScreen] = value
    }
    suspend fun setLockScreenPrivacy(value: String) = editSafely {
        it[Keys.LockScreenPrivacy] = value.takeIf { privacy ->
            privacy in VALID_LOCK_SCREEN_PRIVACY_VALUES
        } ?: SmartIslandSettings.Default.lockScreenPrivacy
    }
    suspend fun setShowNotificationActions(value: Boolean) = editSafely {
        it[Keys.ShowNotificationActions] = value
    }
    suspend fun setHideFromNotificationShade(value: Boolean) = editSafely {
        it[Keys.HideFromNotificationShade] = value
    }

    // ── v3.3 setters ─────────────────────────────────────────────────────────

    suspend fun setIslandBackgroundColor(value: Long) = editSafely {
        it[Keys.IslandBackgroundColor] =
            validColor(value, SmartIslandSettings.Default.islandBackgroundColor)
    }

    suspend fun setIslandBackgroundImagePath(value: String) = editSafely {
        it[Keys.IslandBackgroundImagePath] = value.take(MAX_PATH_LENGTH)
    }

    suspend fun setIslandBackgroundImageAlpha(value: Float) = editSafely {
        it[Keys.IslandBackgroundImageAlpha] = validDimension(
            value,
            SmartIslandSettings.Default.islandBackgroundImageAlpha,
            SmartIslandSettings.MIN_BACKGROUND_IMAGE_ALPHA,
            SmartIslandSettings.MAX_BACKGROUND_IMAGE_ALPHA
        )
    }

    suspend fun setUseArtworkBackground(value: Boolean) = editSafely {
        it[Keys.UseArtworkBackground] = value
    }

    suspend fun setOpenPlayerOnArtworkTap(value: Boolean) = editSafely {
        it[Keys.OpenPlayerOnArtworkTap] = value
    }

    suspend fun setCaptureShelfEnabled(value: Boolean) = editSafely {
        it[Keys.CaptureShelfEnabled] = value
    }

    suspend fun setCaptureWatchScreenshots(value: Boolean) = editSafely {
        it[Keys.CaptureWatchScreenshots] = value
    }

    suspend fun setCaptureWatchClipboard(value: Boolean) = editSafely {
        it[Keys.CaptureWatchClipboard] = value
    }

    suspend fun setCaptureAction(value: String) = editSafely {
        it[Keys.CaptureAction] = value.takeIf { action ->
            action in SmartIslandSettings.VALID_CAPTURE_ACTIONS
        } ?: SmartIslandSettings.Default.captureAction
    }

    suspend fun setSilenceBurstEnabled(value: Boolean) = editSafely {
        it[Keys.SilenceBurstEnabled] = value
    }

    suspend fun setSilenceBurstThreshold(value: Int) = editSafely {
        it[Keys.SilenceBurstThreshold] = value.coerceIn(
            SmartIslandSettings.MIN_BURST_THRESHOLD,
            SmartIslandSettings.MAX_BURST_THRESHOLD
        )
    }

    suspend fun setVisibilityMode(value: String) = editSafely {
        it[Keys.VisibilityMode] = value.takeIf { mode ->
            mode in SmartIslandSettings.VALID_VISIBILITY_MODES
        } ?: SmartIslandSettings.Default.visibilityMode
    }

    suspend fun setHideOnQuickSettings(value: Boolean) = editSafely {
        it[Keys.HideOnQuickSettings] = value
    }

    suspend fun setHideInsideApp(value: Boolean) = editSafely {
        it[Keys.HideInsideApp] = value
    }

    suspend fun setDynamicColorEnabled(value: Boolean) = editSafely {
        it[Keys.DynamicColorEnabled] = value
    }

    suspend fun setThemeMode(value: String) = editSafely {
        it[Keys.ThemeMode] = value.takeIf { mode ->
            mode in SmartIslandSettings.VALID_THEME_MODES
        } ?: SmartIslandSettings.Default.themeMode
    }

    suspend fun resetPosition() = editSafely {
        it[Keys.Width] = SmartIslandSettings.Default.width
        it[Keys.Height] = SmartIslandSettings.Default.height
        it[Keys.XOffset] = SmartIslandSettings.Default.xOffset
        it[Keys.YOffset] = SmartIslandSettings.Default.yOffset
        it[Keys.CornerRadius] = SmartIslandSettings.Default.cornerRadius
    }

    /** Restores every appearance-related preference introduced with the background feature. */
    suspend fun resetIslandBackground() = editSafely {
        it[Keys.IslandBackgroundColor] = SmartIslandSettings.Default.islandBackgroundColor
        it[Keys.IslandBackgroundImagePath] = SmartIslandSettings.Default.islandBackgroundImagePath
        it[Keys.IslandBackgroundImageAlpha] = SmartIslandSettings.Default.islandBackgroundImageAlpha
        it[Keys.UseArtworkBackground] = SmartIslandSettings.Default.useArtworkBackground
    }

    private suspend fun editSafely(transform: suspend (MutablePreferences) -> Unit) {
        try {
            context.smartIslandDataStore.edit(transform)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Log.e(TAG, "Unable to persist settings", error)
        }
    }

    private fun validDimension(
        value: Float?,
        fallback: Float,
        min: Float,
        max: Float
    ): Float = value?.takeIf { it.isFinite() }?.coerceIn(min, max) ?: fallback

    private fun validColor(value: Long?, fallback: Long): Long {
        val color = value ?: return fallback
        val hasValidArgbBits = color in MIN_ARGB_COLOR..MAX_ARGB_COLOR
        val hasVisibleAlpha = (color ushr ALPHA_SHIFT) != 0L
        return if (hasValidArgbBits && hasVisibleAlpha) color else fallback
    }

    private companion object {
        const val TAG = "SmartIslandSettings"
        const val MAX_SHORTCUTS = 8
        const val MAX_PACKAGE_NAME_LENGTH = 255
        const val MAX_PATH_LENGTH = 512
        const val MIN_ARGB_COLOR = 0x01000000L
        const val MAX_ARGB_COLOR = 0xFFFFFFFFL
        const val ALPHA_SHIFT = 24
        val VALID_LOCK_SCREEN_PRIVACY_VALUES = setOf("AppIconOnly", "FullContent")
    }
}
