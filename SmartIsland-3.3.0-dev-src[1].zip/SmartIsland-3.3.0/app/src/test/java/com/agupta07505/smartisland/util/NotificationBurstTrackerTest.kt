/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.agupta07505.smartisland.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationBurstTrackerTest {

    private var now = 0L
    private fun tracker(windowMillis: Long = 60_000L) =
        NotificationBurstTracker(windowMillis = windowMillis, clock = { now })

    @Test
    fun `first notifications below threshold are not silenced`() {
        val tracker = tracker()
        assertFalse(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
        assertFalse(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
    }

    @Test
    fun `third notification from the same app is silenced`() {
        val tracker = tracker()
        tracker.recordAndCheckSilenced("com.example.chat", threshold = 3)
        tracker.recordAndCheckSilenced("com.example.chat", threshold = 3)
        assertTrue(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
        assertTrue(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
    }

    @Test
    fun `counts are tracked per package`() {
        val tracker = tracker()
        repeat(5) { tracker.recordAndCheckSilenced("com.example.chat", threshold = 3) }
        assertFalse(tracker.recordAndCheckSilenced("com.example.mail", threshold = 3))
    }

    @Test
    fun `window expiry lets an app pop again`() {
        val tracker = tracker(windowMillis = 1_000L)
        repeat(3) { tracker.recordAndCheckSilenced("com.example.chat", threshold = 3) }
        assertTrue(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))

        now += 5_000L
        assertFalse(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
    }

    @Test
    fun `reset clears a single package`() {
        val tracker = tracker()
        repeat(4) { tracker.recordAndCheckSilenced("com.example.chat", threshold = 3) }
        assertEquals(4, tracker.countFor("com.example.chat"))

        tracker.reset("com.example.chat")
        assertEquals(0, tracker.countFor("com.example.chat"))
        assertFalse(tracker.recordAndCheckSilenced("com.example.chat", threshold = 3))
    }

    @Test
    fun `non positive threshold never silences`() {
        val tracker = tracker()
        repeat(10) {
            assertFalse(tracker.recordAndCheckSilenced("com.example.chat", threshold = 0))
        }
    }
}
