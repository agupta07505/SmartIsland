# Smart Island 3.3.0-dev — implementation notes

This describes the changes layered on top of 3.2.1. Read the "Not finished"
section before you build: some of the new settings have no UI yet.

**No APK is included.** The environment these changes were written in had no
Android SDK, no Gradle distribution, and no network access, so nothing could be
compiled. The code has been checked for call-site consistency by hand, but it has
**never been through a compiler**. Expect to fix a few things on first build.

---

## 1. Island background customization — done

| File | Role |
| --- | --- |
| `util/IslandBackgroundStore.kt` | new | imports/loads/clears the user's background image |
| `ui/IslandBackgroundLayer.kt` | new | paints colour → image → album art → scrim |
| `ui/IslandOverlayView.kt` | modified | no longer hardcodes black anywhere |
| `ui/IslandCollapsedContent.kt` | modified | centre dot follows the background colour |
| `ui/sections/IslandBackgroundCard.kt` | new | settings card (**not yet wired in — see §7**) |

New settings: `islandBackgroundColor`, `islandBackgroundImagePath`,
`islandBackgroundImageAlpha`, `useArtworkBackground`.

The picked image is **copied** into `filesDir/island_background.png` rather than
stored as a `content://` URI. This is deliberate: the island is rendered by the
accessibility service, and a picker URI grant is not guaranteed to still be
readable after a reboot. The copy is downscaled to a 720px longest edge.

The stack-indicator arcs (drawn when more than one notification is queued) and
the collapsed centre dot both follow the background colour now. If they still
looked black against a custom background, the illusion would break immediately.

---

## 2. Album art opens the music player — done

`MusicExpanded` gained `artworkTapOpensPlayer` and `onOpenPlayer`. The service
implements it as `openMediaApp()`.

**Important:** `openMediaApp()` deliberately does *not* cancel the notification,
unlike the existing `openNotification()`. Cancelling a media notification causes
Spotify, YouTube Music and most other players to pause playback — tapping album
art to open the player and having the music stop would be a bad bug.

Setting: `openPlayerOnArtworkTap` (default on). A small "open in new" badge is
drawn on the artwork so the affordance is discoverable.

---

## 3. Capture shelf (screenshots + copied text) — done, with a caveat

| File | Role |
| --- | --- |
| `model/ShelfItem.kt` | new | one capture |
| `data/ShelfRepository.kt` | new | in-memory, max 8 items, deduped |
| `util/CaptureMonitor.kt` | new | MediaStore observer + clipboard listener |
| `ui/expanded/ShelfExpanded.kt` | new | share / copy / dismiss / clear UI |
| `model/IslandMode.kt` | modified | new `Shelf` mode |

Captures surface through the normal island pipeline (posted as an
`IslandNotification` with `mode = Shelf`), so they inherit the expand animation,
the auto-collapse timer, and swipe handling for free.

Two modes via `captureAction`: `Shelf` (stage it, user taps Share when ready) or
`ShareSheet` (chooser opens immediately).

Shelf contents are **never persisted** and are hidden on the lock screen when
privacy is set to "App icon only" — captures can contain anything.

### ⚠️ Clipboard capture is limited by Android, not by this code

Since Android 10, an app that is not the foreground app or the active IME gets
`null` back from `ClipboardManager.getPrimaryClip()`. There is no permission a
normal app can hold to change this, and being an AccessibilityService does not
grant an exemption.

The listener is registered anyway — it works on Android 9 and on some OEM ROMs
that relax the restriction. When the read comes back empty we skip the capture
rather than showing an empty shelf card.

**Screenshot capture is unaffected and works reliably.** If you only ship one of
the two, ship screenshots.

---

## 4. Silence notifications from a flooding app — done

`util/NotificationBurstTracker.kt` (+ unit tests in
`app/src/test/.../NotificationBurstTrackerTest.kt`).

Rolling 60-second window per package. With the default threshold of 3, the first
two notifications from an app expand the island; the third and beyond are
delivered **silently** — they still land in the notification list, they just stop
animating the island open.

- Incoming calls are exempt. A ringing phone always wins.
- The counter resets for an app once it has nothing left on the island, so the
  next message an hour later pops normally.

Settings: `silenceBurstEnabled`, `silenceBurstThreshold` (2–10).

---

## 5. Visibility rules — done

`util/SystemUiHeuristics.kt` plus `trackWindowChange()`,
`detectShadeFromWindows()` and `shouldHideIsland()` in the overlay service.

All visibility decisions funnel through the single `shouldHideIsland()` function:
landscape, lock screen, quick settings open, inside an app, and
show-only-on-notification.

Settings: `hideOnQuickSettings` (default on), `hideInsideApp` (default off),
`visibilityMode` (`Always` / `OnNotification`).

### ⚠️ Quick settings detection is a heuristic

There is no public API for "is the shade pulled down". Two signals are combined:

1. SystemUI window class names matched against a fragment list
   (`notificationshade`, `qspanel`, `statusbarwindow`, …), with entries for
   MIUI / One UI / OxygenOS SystemUI forks.
2. Whether a `TYPE_SYSTEM` window is currently active or focused.

Combining them is noticeably steadier than either alone, but **expect to tune the
fragment list for whatever device you test on.** Turn on verbose logging for
`SmartIslandOverlayService` and watch the class names as you pull the shade down.

You should also add explicit event types to
`res/xml/accessibility_service_config.xml`:

```xml
android:accessibilityEventTypes="typeWindowStateChanged|typeWindowsChanged"
```

This was **not** applied — the existing config omits the attribute and the 3.2.1
code already depended on receiving these events, so changing it is a behavioural
risk worth testing separately.

---

## 6. Material Design 3 — partially done

**Done:**
- `ui/Theme.kt` rewritten with complete M3 light/dark schemes including
  container / on-container roles. Previously only four colours were set, so
  components like `FilledTonalButton` and `FilterChip` fell back to defaults that
  clashed with the rest of the app.
- Material You dynamic colour on Android 12+, on by default, with
  `dynamicColorEnabled` to turn it off.
- `themeMode` (System / Light / Dark), driven from `MainActivity`.
- Tightened type scale for a settings screen made mostly of two-line rows.
- `ui/components/SettingsComponents.kt` — shared `SettingsCard`,
  `SettingsSwitchRow`, `SettingsChoiceRow`, `SettingsSliderRow`,
  `SettingsActionRow`, `SettingsDivider`.

**Not done:** the existing sections still hand-roll their own Card/Row/Text
stacks. Migrating them to `SettingsComponents` is the remaining redesign work.
This is mechanical but touches ~4,000 lines across nine files.

---

## 7. Not finished — you need to do this

### 7a. Settings UI for the new options (**blocking**)

Every new setting persists correctly and is read by the island, but most have no
UI. Right now they sit at their defaults and cannot be changed from the app.

| Needed | Where |
| --- | --- |
| Wire in `IslandBackgroundCard` | `ui/sections/CustomizationsSection.kt` — the card is written, just not called. Pass `onCustomColorRequested` to the existing `RgbColorPickerDialog` with a new `"background"` target. |
| Capture / shelf section | New `ui/sections/CaptureShelfSection.kt` — toggles for `captureShelfEnabled`, `captureWatchScreenshots`, `captureWatchClipboard`, `captureAction`; plus the runtime permission request. |
| Appearance section | New `ui/sections/AppearanceSection.kt` — `themeMode`, `dynamicColorEnabled`. |
| Visibility + burst rows | `ui/sections/NotificationsAndPrivacySection.kt` — `visibilityMode`, `hideOnQuickSettings`, `hideInsideApp`, `silenceBurstEnabled`, `silenceBurstThreshold`. |
| Navigation entries | `ui/SmartIslandHomeScreen.kt` — add to the `HomeSection` enum and add matching `SectionRow`s. |

### 7b. Manifest permissions (**blocking for screenshot capture**)

```xml
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
    android:maxSdkVersion="32" />
```

`CaptureMonitor.requiredImagePermission()` and
`CaptureMonitor.hasImageReadPermission()` already exist to drive the runtime
request; nothing calls them yet. Without the permission the screenshot observer
logs and returns without registering — it fails safe, but silently.

### 7c. Build config note

`app/build.gradle.kts` has `warningsAsErrors = true` and `abortOnError = true`.
Lint does not run on `assembleDebug`, so this will not block a debug build, but
it **will** fail a release build on any new warning — most likely unused imports
in the files that were edited.

---

## Building

```bash
# Android Studio: open the project and Run.
# Command line (needs the Android SDK installed and ANDROID_HOME set):
./gradlew assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk

./gradlew testDebugUnitTest   # includes the new burst-tracker tests
```

---

## File summary

**New (10):** `data/ShelfRepository.kt`, `model/ShelfItem.kt`,
`ui/IslandBackgroundLayer.kt`, `ui/components/SettingsComponents.kt`,
`ui/expanded/ShelfExpanded.kt`, `ui/sections/IslandBackgroundCard.kt`,
`util/CaptureMonitor.kt`, `util/IslandBackgroundStore.kt`,
`util/NotificationBurstTracker.kt`, `util/SystemUiHeuristics.kt`
(+ `NotificationBurstTrackerTest.kt`)

**Modified (15):** `MainActivity.kt`, `data/SmartIslandNotificationRepository.kt`,
`data/SmartIslandSettings.kt`, `data/SmartIslandSettingsRepository.kt`,
`di/AppModule.kt`, `di/SmartIslandRepositories.kt`, `model/IslandMode.kt`,
`service/SmartIslandNotificationListenerService.kt`,
`service/SmartIslandOverlayService.kt`, `ui/IslandCollapsedContent.kt`,
`ui/IslandOverlayView.kt`, `ui/OverlayIsland.kt`, `ui/Theme.kt`,
`ui/expanded/IslandExpandedContent.kt`, `ui/expanded/MusicExpanded.kt`
(+ `app/build.gradle.kts` version bump)

Upstream is GPL-3.0. The per-file copyright headers were preserved on every
modified file, as GPL-3.0 §4 and §5 and the project's own notice require.
